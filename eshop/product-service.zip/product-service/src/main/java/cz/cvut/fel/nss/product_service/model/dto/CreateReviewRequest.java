package cz.cvut.fel.nss.product_service.model.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Size;

public record CreateReviewRequest(

        @Min(value = 1, message = "Rating must be at least 1.")
        @Max(value = 5, message = "Rating must be at most 5.")
        int rating,

        @Size(max = 1000, message = "Comment can have max 1000 characters.")
        String comment
) {
}